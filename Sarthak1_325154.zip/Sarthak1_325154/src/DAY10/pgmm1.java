package DAY10;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class pgmm1 {
	
	ArrayList<table3> arr_t3 ;
	ArrayList<table2> arr_t2;
	ArrayList<table1> arr_t1;
	public void read_excel_t3()
	
	{
		
		arr_t3 = new ArrayList<table3>();
		try {
			File f= new File("D:\\t3.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh =wb.getSheet("sheet1");
			
			for(int i=1;i<=2;i++)
			{
				
				table3 t3 =new table3();
				
				XSSFRow r= sh.getRow(i);
				
				XSSFCell c= r.getCell(0);
				t3.cid=(int )c.getNumericCellValue();
				
				XSSFCell c1 =r.getCell(1);
				t3.rid= (int)c1.getNumericCellValue();
				
				XSSFCell c2= r.getCell(2);
				t3.no_of_tick =(int)c2.getNumericCellValue();
				
			
				arr_t3.add(t3);
			//	 System.out.print(arr_t3.get(i) + " ");
				t3.display();
				
			}
			
		}
		catch (FileNotFoundException e) {
			  e.printStackTrace();	
			}
			catch( IOException e)
			{
				e.printStackTrace();
			}
		
		
     }
	
public void read_excel_t2()
	
	{
		
		arr_t1 = new ArrayList<table1>();
		try {
			File f= new File("D:\\t1.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh =wb.getSheet("sheet1");
			
			for(int i=1;i<=2;i++)
			{
				
				table2 t2 =new table2();
				
				XSSFRow r= sh.getRow(i);
				
				XSSFCell c= r.getCell(0);
				t2.cust_id=(int )c.getNumericCellValue();
				
				XSSFCell c1 =r.getCell(1);
				t2.c_name= c1.getStringCellValue();
				
				arr_t2.add(t2);
			//	 System.out.print(arr_t3.get(i) + " ");
				t2.display();
				
			}
			
		}
		catch (FileNotFoundException e) {
			  e.printStackTrace();	
			}
			catch( IOException e)
			{
				e.printStackTrace();
			}
		
		
     }
	

public void read_excel_t1()

{
	
	 arr_t1 = new ArrayList<table1>();
	try {
		File f= new File("D:\\t3.xlsx");
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh =wb.getSheet("sheet1");
		
		for(int i=1;i<=2;i++)
		{
			
			table1 t1 =new table1();
			
			XSSFRow r= sh.getRow(i);
			
			XSSFCell c= r.getCell(0);
			t1.rid=(int )c.getNumericCellValue();
			
			XSSFCell c1 =r.getCell(1);
			t1.from= c1.getStringCellValue();
			
			XSSFCell c2= r.getCell(2);
			t1.to=c2.getStringCellValue();
			
			XSSFCell c3= r.getCell(3);
			t1.unit_price=(int)c3.getNumericCellValue();
			
			
		
			arr_t1.add(t1);
		//	 System.out.print(arr_t3.get(i) + " ");
			t1.display();
			
		}
		
	}
	catch (FileNotFoundException e) {
		  e.printStackTrace();	
		}
		catch( IOException e)
		{
			e.printStackTrace();
		}
	
	
 }





}
