package DAY10;

public class table2 {
	
	public int cust_id;
	public String c_name;
	public void display() {
		// TODO Auto-generated method stub
		
	}

}
