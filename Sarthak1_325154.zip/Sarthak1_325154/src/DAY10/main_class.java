package DAY10;


public class main_class extends pgmm1 {
	public void search_t1(int rid)
	{
		
	}

	table3 tt3;
	table2 tt2;
	table4 tt4;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		pgmm1 ex= new pgmm1();
		//ArrayList<passanger> arr_pgl=  new ArrayList<passanger>();
		ex.read_excel_t3();
		ex.read_excel_t2();
		ex.read_excel_t1();
		
		
		
		

	}

}
