package DAY2;

import java.util.Scanner;

public class pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int j=4;
		for(int i=5;i<=9;i++)
		{
			System.out.println(i+ "*" + j+ "="+i*j);
			j=j+2;
		}
	}

}
