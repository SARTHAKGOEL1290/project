package DAY2;

public class prg11 {

	static boolean isprime(int num)
	{
		if(num<=1)
			return false;
		
		for(int i=2;i<num/2;i++)
		{
			if(num%i==0)
				return false;
			
		}
		return true;
		
	}

	public static void main(String[] args) {
	
        int cunt=0;
        int sum =0;
        while(cunt<9)
        {
        	for(int i=2;i<30;i++)
        	{
        		if(isprime(i)==true) {
        			//System.out.println("gteat");
        			sum=sum+i;
        			cunt++;
        		}
        	}
        }
          System.out.println(sum);
	}    
	

}
