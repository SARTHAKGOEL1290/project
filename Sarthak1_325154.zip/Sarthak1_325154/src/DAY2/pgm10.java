
package DAY2;

public class pgm10 {

	public static int add(int x,int y)
	{
		int z;
		z=x+y;
		return z;
	}
	public static void main(String[] args) {

		// TODO Auto-generated method stub
       int a,b=10,c=15;
       a=add(9,8);
       System.out.println(a);
       
        int d=add(b,c);
       System.out.println(d);
	}

}
