package weekend1;

public class pgm1 {
	
	public  static void is_print(String str)
	{
		int lp=str.length();
		if(lp>5)
			System.out.println(str);
	}
	
	public  static void extract_word(String str)
	{
		int L1=0,p1=0,lt=0;
		//lt=str.length();
		String sp;
		while(lt!=str.length())
		{
			L1=str.indexOf(" ",L1);
			sp = str.substring(p1,L1);
		//	System.out.println(sp);
			is_print(sp);
            p1=L1+1;
            L1=L1+1;
            lt=L1;
		}
	
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	@SuppressWarnings("unused")
		String st ="I AM WORKING IN GLOBALOGIC ";
		extract_word(st);

	}

}
