package DAY6;

public class animal {

	int food_amount;
	String food;
	String name;
	String gender;
	int life_span;
	
	
	public void walks(int n) {
		System.out.println("the animal walks:"+ n +"km/day");
	}
	
	public void eats(int n) {
		System.out.println("the animal eats: " + n+ "times in a day");
	}
	
	public void display() {
		System.out.println(" No of amount of food: " +this.food_amount + " Food: " + this.food + " Name: "+this.name 
							+ " Gender: " + this.gender + " Life_span " + this.life_span );
	}
}
