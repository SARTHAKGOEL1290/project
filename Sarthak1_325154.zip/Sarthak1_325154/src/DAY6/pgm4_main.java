package DAY6;

public class pgm4_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ele e1=new ele();
	//	ele e2= new ele();
		
		tiger t1= new tiger();
		//tiger t2= new tiger();
		
		e1.food_amount=20;
		e1.food="sugarcane";
		e1. name="ramu";
		e1 .gender="male";
		e1.life_span=50;
		e1.lot=2;
		e1.lotusks=1;
		
		e1.walks(20);
		System.out.println();
		e1.eats(2);
		System.out.println();
		e1.swim(5);
		System.out.println();
		e1.survilance();
		System.out.println();
		e1.display_ele();
		System.out.println();
		
				
		
	/*	e2.food_amount=30;
		e2.food="sugarcane";
		e2. name="shamu";
		e2 .gender="female";
		e2.life_span=58;
		e1.lot=3;
		e1.lotusks=1;
	
				
		
		e1.walks(20);
		e1.eats(27);
		e1.swim(5);
		e1.survilance();
		e1.display_ele();
		
		*/
		
		t1.food_amount=15;
		t1.food="deer/bufflow";
		t1. name="shera";
		t1 .gender="female";
		t1.life_span=30;
		t1.len_of_teeth=2;
		t1.repul_power=50;
		
		t1.walks(50);
		System.out.println();
		t1.climb(20);
		System.out.println();
		t1.strength(30);
		System.out.println();
		t1.tig_display();

	}

}
