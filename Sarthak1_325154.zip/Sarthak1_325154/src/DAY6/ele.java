package DAY6;

public class ele extends animal {
	
	int lot;
	int lotusks;
	 
	public void swim(int n)
	{
		System.out.println("ele may or may not swim at a speec of"+n +" km/hr");
	}
	public void survilance()
	{
		System.out.println("used in survailance in forest");
	}
	
	public void display_ele()
	{
		
		System.out.println(" amount of food " +this.food_amount + " Food: " + this.food + " Name: "+this.name 
				+ " Gender: " + this.gender + " Life_span " + this.life_span );
		
		System.out.println("length of trunk : " + this.lot + " length of tusk : "+ this.lotusks);
	}

}
