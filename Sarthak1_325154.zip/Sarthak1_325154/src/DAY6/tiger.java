package DAY6;

public class tiger extends animal{
	int len_of_teeth;
	int repul_power;
	
	public void climb(int n)
	{
		System.out.println("tiger able to climb upto"+ n+ "meters");
	}
	
	public void strength(int n)
	{
		System.out.println(" tiger has strength to hold its prey long for"+ 20 +" minutes"  );
	}
	
	public void tig_display()
	{
		
		System.out.println(" amount of food: " +this.food_amount + " Food: " + this.food + " Name: "+this.name 
				+ " Gender: " + this.gender + " Life_span " + this.life_span );
		System.out.println(" len_of teeth :" + this.len_of_teeth + " repul_power : "+ this.repul_power);
	}

}
