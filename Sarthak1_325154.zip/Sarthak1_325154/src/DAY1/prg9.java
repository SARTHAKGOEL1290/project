package DAY1;

public class prg9 {

	public static void main(String[] args) {
		// TODO Auto-genera
		int a=100;
		int b=20;
				
				if(a>b)
					System.out.println("a is greater");
				else if(a<b)
					System.out.println("a is less than b");
				else
					System.out.println("a is equal to b");

	}

}
