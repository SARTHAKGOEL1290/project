package DAY8;

import java.io.File; 
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFEvaluationWorkbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class pgm1 {
	
	public ArrayList<passanger> read_excel()
	{
		ArrayList<passanger> arr_pg=new ArrayList<passanger>();
		try
		{
			File f= new File("D:\\passanger.xlsx");
			FileInputStream fis =new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			
			int fist=sh.getFirstRowNum();
			int last=sh.getLastRowNum();
			
			int nor=last-fist+1;
			for(int i=fist+1;i<=last;i++)
			{
				passanger pg= new passanger();
				
				XSSFRow r= sh.getRow(i);
				
				XSSFCell c= r.getCell(0);
				pg.sr_no= (int)c.getNumericCellValue();
				
				XSSFCell c1= r.getCell(1);
				pg.name = c1.getStringCellValue();
				
				XSSFCell c2= r.getCell(2);
				pg.from = c2.getStringCellValue();
				
				XSSFCell c3= r.getCell(3);
				pg.to = c3.getStringCellValue();
				
				XSSFCell c4= r.getCell(4);
				pg.rate = (int)c4.getNumericCellValue();
				
				XSSFCell c5= r.getCell(5);
				pg.no_of_seats = (int)c5.getNumericCellValue();
				
				
				pg.calc_ttl();
				arr_pg.add(pg);
				
			}
		}
		catch (FileNotFoundException e) {
			  e.printStackTrace();	
			}
			catch( IOException e)
			{
				e.printStackTrace();
			}
			return arr_pg;
           
	}
	public void write_excel(ArrayList<passanger> arr_pg)
	{
		int row=1;
		try
		{
			File f=new File("D:\\passanger.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			for(passanger psg : arr_pg)
			{
				XSSFRow r=sh.getRow(row);
				XSSFCell c= r.createCell(6);
		        c.setCellValue((double) psg.total);
		        row++;
			}
			FileOutputStream fos =new FileOutputStream(f);
			wb.write(fos);
		}
			catch (FileNotFoundException e) {
				  e.printStackTrace();	
				}
				catch( IOException e)
				{
					e.printStackTrace();
				}           
			
		
	}
	
	

}
