package DAY8;

import java.util.ArrayList;

public class pgm2_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		pgm1 ex= new pgm1();
		ArrayList<passanger> arr_pgl=  new ArrayList<passanger>();
		arr_pgl=ex.read_excel();
		ex.write_excel(arr_pgl);
		
	}

}
