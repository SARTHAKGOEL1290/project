package DAY3;
//program to find maximum of each row of given matrix;
public class pgm6 {
	
	public static int findmax(int arr[])
	{
		int large=arr[0];
		for(int i=1;i<arr.length;i++)
		{
		   if(arr[i]>large)
			   large=arr[i];
		}
		return large;
	}

	public static void main(String[] args) {
		int marks[][]={{10,20,30,40},{5,10,15,20},{100,200,300,400}};
		
		
		for(int r=0;r<=2;r++)
			
		{
			int arr2[]=new int[10];
			int k=0;
			for(int c=0;c<=3;c++)
			{
				arr2[k]=marks[r][c];
				k++;
			//	System.out.print(marks[r][c] + " ");
			}
			int l=findmax(arr2);
			//Delete []arr2;
			System.out.println(l);
		}

	}


}
