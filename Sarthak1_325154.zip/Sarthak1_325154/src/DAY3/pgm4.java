package DAY3;
// program to print given matrix;
public class pgm4 {
	
	
	public static void main(String[] args) {
		int mat[][]={{10,20,30,40},{5,10,15,20},{100,200,300,400}};
		
		
		for(int r=0;r<=2;r++)
			
		{
			
			for(int c=0;c<=3;c++)
			{
				System.out.print(mat[r][c] + " ");
			}
			
			
			System.out.println();
		}

	}

}
