package DAY7;


	
	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.FileOutputStream;
	import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
	import org.apache.poi.xssf.usermodel.XSSFRow;
	import org.apache.poi.xssf.usermodel.XSSFSheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;

	import DAY3.student;

		
	public class PGM1 {
		public ArrayList<student> read_excel()
		{
			// TODO Auto-generated method stub
			
			
			ArrayList<student> arr_lst =new ArrayList<student>();
			 
						try {
							File f =new File("D:\\student_info.xlsx");
							FileInputStream fis = new FileInputStream(f);
							XSSFWorkbook wb = new XSSFWorkbook(fis);
							XSSFSheet sh = wb.getSheet("Sheet1");
                            
							int fist=sh.getFirstRowNum();
							int last=sh.getLastRowNum();
							int nor=last-fist +1;
							for(int i=fist+1;i<=nor-1;i++)
							{
								student std= new student();
								
								XSSFRow r=sh.getRow(i);
								
								XSSFCell c= r.getCell(0);
								std.roll_no= (int) c.getNumericCellValue();
								
								XSSFCell c1 =r.getCell(1);
								std.name = c1.getStringCellValue();
								
								
								XSSFCell c2 =r.getCell(2);
						        std.m1 = (int) c2.getNumericCellValue();
						        
						        XSSFCell c3 =r.getCell(3);
						        std.m2 = (int) c3.getNumericCellValue();
								
								std.average();
								arr_lst.add(std);
								
							}
							
							
						//	String s= c.getStringCellValue();
							//System.out.println(s);
						}
						catch (FileNotFoundException e) {
						  e.printStackTrace();	
						}
						catch( IOException e)
						{
							e.printStackTrace();
						}
						return arr_lst;
	                     
						
		}
		public void write_excel(ArrayList<student>arr_lst )
		{
			int row=1;
		try {
			File f =new File("D:\\student_info.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			for(student  std: arr_lst)
			{
			XSSFRow r=sh.getRow(row);
			XSSFCell c= r.createCell(4);
	        c.setCellValue((double) std.avg);
	        row++;
			}
			
		   FileOutputStream fos = new FileOutputStream(f);
		   wb.write(fos);
		}
		catch (FileNotFoundException e) {
		  e.printStackTrace();	
		}
		catch( IOException e)
		{
			e.printStackTrace();
		}

	}
	

	}


