package DAY4;

//import java.util.*;


public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       String s="I AM WORKING IN GLOBALLOGIC IN NOIDA ";
       String s2 ;
      int lt=0,L1=0,p2=0;
       //lt is used for iterate over string length  .
 //L1 is used for finding space location.
      //p2 is used for getting the starting symbol of word.u
      while(lt <s.length())
       {
    	   L1=s.indexOf(" ",L1);
    	   s2=s.substring(p2,L1);
    	   System.out.println(s2);
    	   p2=L1+1;
    	   L1=L1+1;
    	   lt=L1;
       }
	}

}
