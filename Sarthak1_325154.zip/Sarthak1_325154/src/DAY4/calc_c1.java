package DAY4;

public class calc_c1 {
	 public int add(int x,int y)
	 {
		 int z=x+y;
		 return z;
		 
	 }
	 public int add(int x,int y,int z)
	 {
		 int  sd =x+y+z;
	     return  sd;
	 }
	 public float add(int x,int y,float z)
	 {
		 float f=x+y+z;
		 return f;
	 }

}
