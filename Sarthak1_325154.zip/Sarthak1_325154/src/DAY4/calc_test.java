package DAY4;

public class calc_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		calc_c1 calc = new calc_c1();
		int sum = calc.add(5,6);
		System.out.println("first sum =" +  sum );
		
		int  s=  calc.add(2,3,4);
		System.out.println("second sum = " + s);

		float f1 =calc.add(2,5,9.8f);
		System.out.println("third sum = " + f1);
		
	}

}
