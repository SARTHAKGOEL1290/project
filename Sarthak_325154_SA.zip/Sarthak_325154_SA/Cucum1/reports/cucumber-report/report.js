$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("a.feature");
formatter.feature({
  "line": 1,
  "name": "AUT login",
  "description": "",
  "id": "aut-login",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "To verify login for valid data",
  "description": "",
  "id": "aut-login;to-verify-login-for-valid-data",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@ROUND2"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User enters login details",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Home page is displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "test1.login_page_is_displayed()"
});
formatter.result({
  "duration": 6442618900,
  "status": "passed"
});
formatter.match({
  "location": "test1.user_enters_login_details()"
});
formatter.result({
  "duration": 1587908000,
  "status": "passed"
});
formatter.match({
  "location": "test1.home_page_is_displayed()"
});
formatter.result({
  "duration": 35293199,
  "error_message": "java.lang.AssertionError: The following asserts failed:\n\texpected [sarthakgoel1290@gmail.com] but found [sarthakgoel10@gmail.com]\r\n\tat org.testng.asserts.SoftAssert.assertAll(SoftAssert.java:43)\r\n\tat STEP_DEF.test1.home_page_is_displayed(test1.java:41)\r\n\tat ✽.Then Home page is displayed(a.feature:7)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 10,
  "name": "To verify login for invalid data",
  "description": "",
  "id": "aut-login;to-verify-login-for-invalid-data",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 9,
      "name": "@ROUND2"
    }
  ]
});
formatter.step({
  "line": 11,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 12,
  "name": "User enters wrong login details",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "Home page is not displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "test1.login_page_is_displayed()"
});
formatter.result({
  "duration": 5949034700,
  "status": "passed"
});
formatter.match({
  "location": "test2.user_enters_wrong_login_details()"
});
formatter.result({
  "duration": 754292500,
  "status": "passed"
});
formatter.match({
  "location": "test2.home_page_is_not_displayed()"
});
formatter.result({
  "duration": 5889900,
  "status": "passed"
});
});