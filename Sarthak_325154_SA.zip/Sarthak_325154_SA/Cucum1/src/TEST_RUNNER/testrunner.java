package TEST_RUNNER;

import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="FEATURES",glue="STEP_DEF")
public class testrunner extends AbstractTestNGCucumberTests{
 
  }