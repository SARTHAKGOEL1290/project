package S_day6;

import org.testng.annotations.Test;

public class NewTest {
  @Test(priority=1)
  public void b() {
	  System.out.println("in b");
	  
  }
  @Test(priority=3)
  public void c() {
	  System.out.println("in c");
  }
  @Test(priority=6)
  public void a() {
	  System.out.println("in a");
  }
}
