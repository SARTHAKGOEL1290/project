package S_day6;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import S_day4.check_login;
import S_day4.data_class;

public class NewTest5 {
	data_class ldd,ldd1;
	check_login cll;
	@BeforeClass
	public void config()
	{
		ldd= new data_class();
		ldd1=new data_class();
		cll= new check_login();
	}
  @Test(dataProvider= "Security")
  public void log(String s,String u,String r) {
	  System.out.println("login id=="+ s+ " "+ "pass is=="+ u);
	  ldd.email=s;
	  ldd.pwd=u;
	  ldd.exp_res=r;
      ldd1=cll.login(ldd);
	  
	  SoftAssert sa= new SoftAssert();
	  sa.assertEquals(ldd.exp_res, ldd1.acc_res);
	sa.assertAll();
	 
	  
	  
  }
  @DataProvider(name="Security")
  public String [][]getdata(){
	  String [][] data= {{"sarthakgoel1290@gmail.com","kuchnahi","sucess"},
			             {"sarthakgoel1290@gmail.com","pwd","sucess"}};
	  return data;
	  }
}
