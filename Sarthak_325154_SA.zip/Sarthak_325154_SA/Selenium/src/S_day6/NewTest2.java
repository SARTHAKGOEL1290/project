package S_day6;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest2 {
  @Test(priority=2)
  public void c() {
	  String ar="noida" ,ar1="noida";
	  Assert.assertEquals(ar, ar1);
	  System.out.println("in c func");
	  
	  
  }
  @Test(priority=5)
  public void a() {
	  String ar="noida" ,ar1="noida1";
	  Assert.assertEquals(ar, ar1);
	  System.out.println("in a func");
	  }
  @Test(priority=4)
  public void b() {
	  String ar="noida" ,ar1="noida1";
	  SoftAssert sa= new SoftAssert();
	  sa.assertEquals(ar, ar1);
	  System.out.println("in b func");
//	  sa.assertAll();
}
}
