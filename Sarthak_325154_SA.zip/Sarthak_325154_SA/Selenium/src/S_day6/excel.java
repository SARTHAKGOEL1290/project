package S_day6;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class excel {

	String data;
	
	public String read(int n,int c)
	{
		try {
			File f =new File("D://TESTDATA11.xlsx");
			FileInputStream fis =new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh= wb.getSheet("Sheet2");
			
            XSSFRow r= sh.getRow(n);
			
			XSSFCell c1=r.getCell(c);
			data=c1.getStringCellValue();
			//System.out.println(data);
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return data;
	}
	public int write(int n)
	{
		try
		{
		File f=new File("D://TESTDATA11.xlsx");
		FileInputStream fis =new FileInputStream(f);
		XSSFWorkbook wb= new XSSFWorkbook(fis);
		XSSFSheet sh= wb.getSheet("Sheet2");
		
		XSSFRow r= sh.getRow(n);
		
		XSSFCell c=r.createCell(6);
		c.setCellValue("valid user");
		
		FileOutputStream fos= new FileOutputStream(f);
		wb.write(fos);
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}

}
