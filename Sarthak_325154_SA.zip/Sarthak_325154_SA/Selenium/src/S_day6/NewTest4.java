package S_day6;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class NewTest4 {
  @Test(dataProvider="Security")
  public void login(String u,String v) {
	  
	  System.out.println("login: "+ u +" "+ " pass: "+v);
	  
  }
  @DataProvider(name="Security")
  public String [][]getdata(){
	  String [][] data= {{"uid","pwd"},
			             {"uid","pwd"}};
	  return data;
	  }
  }

