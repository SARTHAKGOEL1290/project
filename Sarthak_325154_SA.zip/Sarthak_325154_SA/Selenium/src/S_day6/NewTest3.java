package S_day6;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import S_day4.check_login;
import S_day4.data_class;
   
public class NewTest3 {
	data_class tdd,tdd1;
	check_login cll;
  @Test
  public void a() {
	  tdd= new data_class();
	  tdd1=new data_class();
	  cll=new check_login();
	  
	  tdd.email="sarthakgoel1290@gmail.com";
	  tdd.pwd="kuchnahi";
	  tdd.exp_res="Sucess";
	 
	  tdd1=cll.login(tdd);
	  
	  SoftAssert sa= new SoftAssert();
	  sa.assertEquals(tdd.exp_res, tdd1.acc_res);
	//  sa.assertAll();
	  System.out.println("acctual result is"+ tdd1.acc_res);
  }
  @Test
  public void b() {
	  tdd= new data_class();
	  tdd1=new data_class();
	  cll=new check_login();
	  
	  tdd.email="sarthakgoel1290@gmail.com";
	  tdd.pwd="bhulgaya";
	  tdd.exp_res="Sucess";
	 
	  tdd1=cll.login(tdd);
	  
	  SoftAssert sa= new SoftAssert();
	  sa.assertEquals(tdd.exp_res, tdd1.acc_res);
	 
	  System.out.println("acctual email is   "+ tdd1.acc_res);
	  sa.assertAll();
  }
}
