package S_day4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_orp_lis extends data_class_lis{
	static ArrayList<data_class_lis>arr1=new ArrayList<data_class_lis>();

	public void readexcel()
	{
		 
		try {
		
			File f =new File("D://TESTDATA11.xlsx");
			FileInputStream fis =new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh= wb.getSheet("Sheet1");
			for(int i=1;i<=4;i++) {
				data_class_lis testdata= new data_class_lis();
				
			XSSFRow r= sh.getRow(i);
			
			XSSFCell c=r.getCell(0);
			testdata.email=c.getStringCellValue();
			
			XSSFCell c1= r.getCell(1);
			testdata.pwd=c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(2);
			testdata.exp_res= c2.getStringCellValue();
			
			XSSFCell c3= r.getCell(3);
			testdata.exp_msg1=c3.getStringCellValue();
			
			XSSFCell c4= r.getCell(4);
			testdata.exp_msg2=c4.getStringCellValue();
			
			arr1.add(testdata);
			System.out.println(testdata.exp_msg2);
			}
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	 //return testdata;
		//return null;
		
	}
	public void writeexcell(ArrayList<data_class_lis>arrl1)
	{
		int i=1;
		try {
			File f =new File("D://TESTDATA11.xlsx");
			FileInputStream fis =new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh= wb.getSheet("Sheet1");
		    for(data_class_lis testdata : arrl1)
			{
				
			 XSSFRow r=sh.getRow(i);
		     XSSFCell c=	r.createCell(5);
		     c.setCellValue(testdata.acc_res);
		    
		    XSSFCell c1=	r.createCell(6);
		    c1.setCellValue(testdata.acc_msg1);
		    
		    XSSFCell c2=	r.createCell(7);
		    c2.setCellValue(testdata.acc_msg2);
		    
		    XSSFCell c3=	r.createCell(8);
		    c3.setCellValue(testdata.result);
		    i++;
		 
		  }
		    
		    
			FileOutputStream fos= new FileOutputStream(f);
			wb.write(fos);
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	

}
