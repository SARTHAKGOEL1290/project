package S_day4;

public class data_class_lis {
	public String email,pwd,exp_res,exp_msg1,exp_msg2;
	public String acc_res,acc_msg1,acc_msg2,result;
	 
  
	// TODO Auto-generated method stub
	public data_class_lis(String email, String pwd, String exp_res, String exp_msg1, String exp_msg2, String acc_res,
			String acc_msg1, String acc_msg2, String result) {
		super();
		this.email = email;
		this.pwd = pwd;
		this.exp_res = exp_res;
		this.exp_msg1 = exp_msg1;
		this.exp_msg2 = exp_msg2;
		this.acc_res = acc_res;
		this.acc_msg1 = acc_msg1;
		this.acc_msg2 = acc_msg2;
		this.result = result;
	}
	
	public data_class_lis()
	{
		
	}



	public void display()
	{
		System.out.println("resulted data is");
		
		System.out.println("email is --.>"+ this.email);
		System.out.println("password is--->"+this.pwd);
		System.out.println("exp result is ---->"+this.exp_res);
		System.out.println("exp message 1 is--->"+this.exp_msg1);
		System.out.println("exp message 2 is ---->"+this.exp_msg2);
		
		System.out.println("acctual result->>>"+this.acc_res);
		System.out.println("acctual message1 is--->>"+this.acc_msg1);
		System.out.println("acctual message2 is--->>"+ this.acc_msg2);
		System.out.println("final result is--->"+ this.result);
		
		
	}


	
}
