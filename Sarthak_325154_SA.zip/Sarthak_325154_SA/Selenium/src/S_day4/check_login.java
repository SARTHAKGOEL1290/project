package S_day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class check_login extends excell_opr {

	public data_class login(data_class testdata)
	{
		//testdata=new data_class();
	//	System.out.println("hello");
	  //   System.out.println(testdata.email);
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr= new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		
        dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(testdata.email);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(testdata.pwd);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		boolean f= dr.getTitle().contains("Login");
		
		if(!f)
		{
			testdata.acc_res="sucess";
			testdata.result="pass";
		}
		else
		{
			testdata.acc_res="Failure";
		    testdata.acc_msg1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
		//    System.out.println(testdata.acc_msg1);
		    testdata.acc_msg2= dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
          //  System.out.println(testdata.acc_msg2);		
		}
	/*	if(testdata.exp_res=="Failure")
		{
			if(testdata.exp_msg1.equals(testdata.acc_msg1) && testdata.exp_msg2.equals(testdata.acc_msg2))
			{
				testdata.result="Pass";
				//System.out.println("true");
			}
			else
			{
				testdata.result="Fail";
				//System.out.println("false");
			}
			
		}*/
		arr1.add(testdata);
		System.out.println(arr1.size());
		return testdata;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			check_login cl=new check_login();
	       // cl.readexcel();
			
			
			//	check_login cl1=new check_login();
			
			for(int i=1;i<=2;i++)
			{
				//if(i==1) {
		    data_class tdd =new data_class();
		    data_class tdd1=new data_class();
			tdd=cl.readexcel(i);
			tdd1=cl.login(tdd);
			cl.writeexcell(tdd1,i);
		    }
			//if(i==2)
			/*{
				 data_class tdd12 =new data_class();
				    data_class tdd11=new data_class();
					tdd12=cl1.readexcel();
					tdd11=cl1.login(tdd12);
					cl1.writeexcell(tdd11);
			}
			}*/
		}
			//cl.display();
			
	
		

		
	

}
