package S_day3;

///this is assignment program....

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class pgm4 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		                               System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
     /* launching the browser*/	       WebDriver dr= new ChromeDriver();
     /* launching the website*/        dr.get("http://demowebshop.tricentis.com/");
		 
     String s="aba"+ "aaaaabcdwxyzzz1290@gmail.com";
		
     /* launching the register button*/	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
		
     /* launching the radio button*/    List lb=dr.findElements(By.name("Gender"));
		                                ((WebElement)lb.get(0)).click();
	//((WebElement)lb.get(1)).click();
		 /* entering the first name*/	dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys("sarthak");
		 /* entering the last name*/    dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys("goel");
		 /* entering the email*/        dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(s);
		 /* entering the pass*/         dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("patanahi");
		
		 /* entering the confirm pass*/ dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys("patanahi");
		 /* click register button*/     dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
		
		 /* finding the relevant text*/ String st= dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]")).getText();
		                                System.out.println(st);
		                                
		                 /*validity of valid user*/               String st1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		                             if(st1.equals(s))
		                               System.out.println("valid user");
		 /* log out */	              
		                                //WebDriverWait wt= new  WebDriverWait(dr,10);
		                              //  wt.until(ExpectedConditions.urlContains(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")))
		                                dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		 /* close the browser*/        dr.close();
		                                System.out.println("logged out");
	}

}
