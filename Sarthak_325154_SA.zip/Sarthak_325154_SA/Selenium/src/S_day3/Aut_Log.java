package S_day3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Aut_Log {
	
	 static read_table testdata;
	public static read_table readexcel()
	{
		try {
			testdata= new read_table();
			File f =new File("D://auto_login_faeture.xlsx");
			FileInputStream fis =new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh= wb.getSheet("Sheet1");
			
			XSSFRow r= sh.getRow(1);
			
			XSSFCell c=r.getCell(0);
			testdata.uid=c.getStringCellValue();
			
			XSSFCell c1= r.getCell(1);
			testdata.pwd=c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(2);
			testdata.exp_res= c2.getStringCellValue();
			
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	 return testdata;
		
	}
	public static  void login_aut()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr= new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(testdata.uid);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(testdata.pwd);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		String st=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		
		if(st.equals(testdata.exp_res)) {
			testdata.acc_res=st;
			testdata.test_result="pass";
		}
			
	}
	public static void writeexcel()
	{
		try {
			File f =new File("D://auto_login_faeture.xlsx");
			FileInputStream fis =new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh= wb.getSheet("Sheet1");
			
			XSSFRow r=sh.getRow(1);
		    XSSFCell c=	r.createCell(3);
		    c.setCellValue(testdata.acc_res);
		    
		    XSSFCell c1=	r.createCell(4);
		    c1.setCellValue(testdata.test_result);
		    
		    
			FileOutputStream fos= new FileOutputStream(f);
			wb.write(fos);
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
	}
	public static void main(String args[])
	{
		 testdata=readexcel();
		login_aut();
		writeexcel();
		
	}

}
