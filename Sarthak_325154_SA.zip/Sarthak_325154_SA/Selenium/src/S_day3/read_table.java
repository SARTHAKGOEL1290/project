package S_day3;

public class read_table {
	
	public String uid;
	public String pwd;
	public String exp_res;
	public String acc_res;
	public String test_result;

}
