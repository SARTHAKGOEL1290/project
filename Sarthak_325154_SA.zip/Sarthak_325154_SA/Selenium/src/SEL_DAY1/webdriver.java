package SEL_DAY1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class webdriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr= new ChromeDriver();
		dr.get("https://www.facebook.com");
	/*	WebElement we1= dr.findElement(By.id("day"));
		Select sel= new Select(we1);
		sel.selectByVisibleText("15");
		
		//for month
		WebElement we2= dr.findElement(By.id("month"));
		Select sell= new Select(we2);
		sell.selectByVisibleText("Jun");
		
		//for year
		WebElement we3= dr.findElement(By.id("year"));
		Select selll = new Select(we3);
		selll.selectByVisibleText("1997");
		*/
		/// for login
	    dr.findElement(By.name("email")).sendKeys("sarthakgoel1290@gmail.com");
		dr.findElement(By.name("pass")).sendKeys("");
		dr.findElement(By.xpath("//*[@id=\"loginbutton\"]")).click();
		
		String actual= dr.findElement(By.xpath("//*[@id=\"u_0_a\"]/div[1]/div[1]/div/a/span/span")).getText();
	   String exp="Sarthak";
	    if( actual.equals(exp))
	    {
	    	System.out.println("sucess");
	    }
		
		///for radio button.
	/*	String title =dr.getTitle();
		System.out.println("Title is "+ title);
		
		List lb=dr.findElements(By.name("sex"));
		((WebElement)lb.get(0)).click();
		((WebElement)lb.get(1)).click();
		*/
		


	}

}
