package GRID;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Grid_hub_1 {
	
	WebDriver dr;
	String autUrl,nodeUrl;
	
	@BeforeClass
	public void setup() throws MalformedURLException
	{
		autUrl =" https://www.facebook.com";
		nodeUrl="http://172.16.70.55:5566/wd/hub";
		
		DesiredCapabilities cap =DesiredCapabilities.firefox();
		cap.setBrowserName("firefox");
		cap.setPlatform(Platform.WINDOWS);
		
		dr=new RemoteWebDriver(new URL(nodeUrl),cap);
	}
  @Test
  public void t1() {
	  
	  dr.get("https://www.facebook.com");
  }
}
