package S_weekand2;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class driver_class extends read_func {

	static test_case_sel tc =new test_case_sel();
	static keyword kw=new keyword();
	static String filename ="D://hhfw.xlsx";
	
	
	public static void main(String[] args) throws IOException  {
		// TODO Auto-generated method stub
		WebDriver dr=null;
		support we= new support(dr);
		
		int i,j,ik=0,k=0;
		String id,ua,key,xpth,tdata;
	
		for( i=1;i<=3;i++)
		{ 
			tc=  readsel(i);
			
			for( j=1;j<=15;j++)
			{
				kw=read_kw_sh(j);
				
				if(tc.tc_id.equals(kw.TC_ID))
				{
					//System.out.println("hi");
					tc.flag="Y";
					k=j;
					break;
					
				}
				else
					continue;
				
				
			}
		//	System.out.println("ALL");
			if(tc.flag.equals("Y")) {
			get_test_data();
			
			System.out.println(ar_td.size());
		//	System.out.println(ar_td);
			
			for(data_sel ds : ar_td)
			{ 
				System.out.println(ds.uid);
				System.out.println(ds.pass);
				ik=k;
				for( ;ik<(k+tc.no_steps);ik++)
				{
					
					//System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
					 //dr= new ChromeDriver();
					//dr.get("http://demowebshop.tricentis.com/");
					kw=read_kw_sh(ik);
					System.out.println(ik);
				    id=kw.TC_ID;
				    System.out.println(id);
				    ua=kw.user_act;
				    System.out.println(ua);
				    key=kw.keyword;
				    System.out.println(key);
				    xpth=kw.xpath;
				    System.out.println(xpth);
				    tdata=kw.test_data;
				    System.out.println(tdata);
				    if(ua.equals("enter user_id")|| ua.equals("verify user"))
				    {
				    	tdata=ds.uid;
				    }
				    if(ua.equals("enter password"))
				    {
				    	tdata=ds.pass;
				    }
				  
				    
				    switch(key)
		        	{
				    
		        	case "launchchrome" :
		        		System.out.println("hii");
		        		we.launch(tdata);
		        		break;
		        		
		        	case "enter_txt" :
		        		we.enter(xpth,tdata);
		        		break;
		        		
		        	case "click_btn" :
		        		we.click(xpth);
		        		break;
		        		
		        	case "verify" :
		        		we.verify(xpth,tdata);
		        		break;
		        		
		        	case "sel_gen" :
		        		we.gender(xpth);
		        		break;
		        	}
				}
				
			}
		  }
		}

	}

	

}
