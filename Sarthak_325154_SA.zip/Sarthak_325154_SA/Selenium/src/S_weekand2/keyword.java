package S_weekand2;

public class keyword {
	public String TC_ID;
	
	public String user_act;  
	public String keyword;
	public String xpath;
	
	public String test_data;
}
