package S_weekand2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class support {
	WebDriver dr;
	//String s="Your registration completed";
	//String s1="goelsarthu99900@gmail.com";
	support(WebDriver dr)
	{
		this.dr=dr;
	
	}
	public void enter(String xp,String data)
	{
		//s=data;
		dr.findElement(By.xpath(xp)).sendKeys(data);
		
	}
	public void click(String xp)
	{
		dr.findElement(By.xpath(xp)).click();
	}
	public void gender(String xp)
	{
		int lp;
		System.out.println(xp);
		if(xp.equals("M"))
		{	lp=0;}
		else {
			lp=1;
		}
	//	int p=Integer.parseInt(xp);
		 List lb=dr.findElements(By.name("Gender"));
         ((WebElement)lb.get(lp)).click();
	}
	
	public void launch(String url)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		 dr= new ChromeDriver();
		dr.get(url);
		//dr.findElement(By.xpath(//*[@id="Email"])).sendKeys();
	}
	public void verify(String xp,String td)
	{
		String st=dr.findElement(By.xpath(xp)).getText();
		if(st.equals(td)==true)
		{
			System.out.println("pass");
		}
		else
		{
			System.out.println("fail");
		}
	}

}
