package S_weekand2;

public class test_case_sel {
	public String tc_id;
	public String flag;
	public int no_steps;
	public String sheet_name;
	public String fin_res;

}
