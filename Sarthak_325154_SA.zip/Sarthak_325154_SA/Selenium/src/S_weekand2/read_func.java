package S_weekand2;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class read_func {
	
	
	public static String select_sh="TC_SELECT_SH";
	public static String keyword="KEYWORD_SH";
	public static String log="LOGINDATA";
	public static String filename="D://hhfw.xlsx";
	public static XSSFSheet tc_sh,td_sh,kw_sh;
	static ArrayList<test_case_sel> ar_tc=new ArrayList<test_case_sel>();
	public static ArrayList<data_sel> ar_td;
	
	
	
	public static XSSFSheet get_read_sheet(String  sheetname)
	{
		XSSFSheet sh=null;
		
		try {
		   File f=new File(filename);
		   FileInputStream fis= new FileInputStream(f);
		   XSSFWorkbook wb = new XSSFWorkbook(fis);
		   sh= wb.getSheet(sheetname);
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return sh;
	}
	public static void get_test_data()
	{
		
		ar_td=new ArrayList<data_sel>();
		td_sh=get_read_sheet(log);
		int fis=td_sh.getFirstRowNum();
		int last =td_sh.getLastRowNum();
	    try {
	    	for(int i=1;i<=2;i++)
	    	{
	    		data_sel td= new data_sel();
	    		XSSFRow r= td_sh.getRow(i);
	    		
	    		td.uid=r.getCell(0).getStringCellValue();
	    		
	    		td.pass=r.getCell(1).getStringCellValue();
	    		ar_td.add(td);
	    		
	    		
	    			    	}
	    	
	    	
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
	}
	public static test_case_sel readsel(int i)
	{
		test_case_sel tc=new test_case_sel();
		try {
			tc_sh=get_read_sheet(select_sh);
			// int fis=tc_sh.getFirstRowNum();
			 //int last=tc_sh.getLastRowNum();
		//	for(int i=fis;i<=last;i++)
			//{
				XSSFRow r=tc_sh.getRow(i);
				
				tc.tc_id=r.getCell(0).getStringCellValue();
				tc.flag =r.getCell(1).getStringCellValue();
				tc.no_steps=(int) r.getCell(2).getNumericCellValue();
				tc.sheet_name=r.getCell(3).getStringCellValue();
		//		tc.fin_res=r.getCell(4).getStringCellValue();
				
			//	ar_tc.add(tc);
		//	}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return tc;
	}
	public static keyword read_kw_sh(int j)throws IOException{
		keyword kw=new keyword();
		
		kw_sh= get_read_sheet(keyword);
		XSSFRow rw=kw_sh.getRow(j);
		
		kw.TC_ID=rw.getCell(0).getStringCellValue();
		kw.user_act=rw.getCell(1).getStringCellValue();
		kw.keyword=rw.getCell(2).getStringCellValue();
		kw.xpath=rw.getCell(3).getStringCellValue();
		kw.test_data=rw.getCell(4).getStringCellValue();
		
		return kw;
		
	}	
	

}
