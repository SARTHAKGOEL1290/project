package S_weekand2;

public class data_sel {
	public String uid;
	public String pass;

}
