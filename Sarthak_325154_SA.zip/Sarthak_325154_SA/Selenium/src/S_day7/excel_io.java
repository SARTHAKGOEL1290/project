package S_day7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class excel_io {
	
	public static String [][]data;
	public static int row,col;
	
	public static void gettext(int n)
	{
		try
		{
			File f= new File("D://TESTDATA12.xlsx");
			FileInputStream fis= new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh= wb.getSheet("Sheet1");
			
		
			XSSFRow r= sh.getRow(n);
			
			XSSFCell c=r.getCell(0);
			data[n-1][0]=c.getStringCellValue();
			
			XSSFCell c1= r.getCell(1);
            data[n-1][1]=c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(2);
			data[n-1][2]= c2.getStringCellValue();
			
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	

}
