package S_day7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class aut_log extends excel_io{

	public static  String login(String s,String u,String v)
	{
		//testdata=new data_class();
	//	System.out.println("hello");
	  //   System.out.println(testdata.email);
		String a_result;
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr= new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		
        dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(s);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(u);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		boolean f= dr.getTitle().contains("Login");
		
		if(!f)
		{
			 a_result = "success";
			 System.out.println("login success");
			 dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		}
		else
		{
			a_result= "fail";
		}
		dr.close();
		return a_result;
		
	}
}