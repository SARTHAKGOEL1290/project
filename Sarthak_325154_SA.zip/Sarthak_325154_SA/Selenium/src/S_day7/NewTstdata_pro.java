package S_day7;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTstdata_pro extends aut_log{
  @BeforeClass
  public void config()
  {
	  data=new String[3][3];
	  for(row=1;row<=3;row++)
	  {
		  gettext(row);
	  }
  }
	
	@Test(dataProvider="data1")
     public void login_test(String x,String y,String z)
		{
			String a_res;
			a_res=login(x,y,z);
			System.out.println(a_res);
			System.out.println(z);
			SoftAssert sa= new SoftAssert();
			sa.assertEquals(a_res, z);
			sa.assertAll();
		}
  
	@DataProvider(name="data1")
	public String [][] getdata() {
		return data;
	}
	
}
