package S_Day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm3 {
	
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr= new ChromeDriver();
		String url="https://www.w3schools.com/html/html_tables.asp";
		dr.get(url);
		//*[@id="customers"]/tbody/tr[1]/th[1]
		String s=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr[1]/th[1]")).getText();
		System.out.println(s);
		String s1=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr[2]/td[1]")).getText();
		System.out.println(s1);
		
		//int r=5,c=2;
		//WebElement s3=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr["+ r + "]/td["+ c + "]"));
		
				
	}

}
