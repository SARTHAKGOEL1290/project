package S_day8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class login_page {
	
	static WebDriver dr;
	static By xname= By.xpath("//*[@id=\"user-name\"]");
	static By xpwd= By.xpath("//*[@id=\"password\"]");
	static By xbtn= By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]");
	
	public login_page(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	public static void name(String uid)
	{
		dr.findElement(xname).sendKeys(uid);
	}
	public static void pass(String pwd)
	{
		dr.findElement(xpwd).sendKeys(pwd);
	}
	public static void clic()
	{
		dr.findElement(xbtn).click();;
	}
	public  void login(String uid,String pwd)
	{
		this.name(uid);
		this.pass(pwd);
		this.clic();
		
	}
	public String get_login_title()
	{
		return dr.getTitle();
	}
	

}
