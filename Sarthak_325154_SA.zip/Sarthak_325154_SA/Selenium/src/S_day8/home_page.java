package S_day8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class home_page {
	
	
	
	  //div[@class='inventory_item'][1]//div[@class='inventory_item_name']
	//div[@class='inventory_item'][1]//div[@class='inventory_item_price']
	//div[@class='inventory_item'][1]//button
	WebDriver dr;
	String base_xp=" //div[@class='inventory_item'][";
	By xname,xprice,xbtn;
	
	public home_page(WebDriver dr) {
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	public String get_prod_name(int n)
	{
		xname=By.xpath(base_xp+n+"]//div[@class='inventory_item_name']");
		String pname=dr.findElement(xname).getText();
		return pname;
	}
	public String get_prod_price(int n)
	{
		xprice=By.xpath(base_xp+n+"]//div[@class='inventory_item_price']");
		String price=dr.findElement(xprice).getText();
		return price;
	}
	public void add_cart(int n)
	{
		xbtn=By.xpath(base_xp+n+"]//button");
	     dr.findElement(xbtn).click();
	}
	public void click_btn()
	{
		dr.findElement(By.xpath("//div[@class='shopping_cart_container']")).click();
	}

}
