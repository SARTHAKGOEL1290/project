package S_day8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class cart_page {
	//div[@class='cart_item'][1]//div[@class='inventory_item_name']
	//div[@class='cart_item'][1]//div[@class='inventory_item_price']
	//*[@id="shopping_cart_container"]/a/svg/path
	WebDriver dr;
	String base_xp1="//div[@class='cart_item'][";
	By xconf;
	
	public cart_page(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	public String verify(int n)
	{
	   xconf=By.xpath(base_xp1+n+"]//div[@class='inventory_item_name']");
	   String acc=dr.findElement(xconf).getText();
	   return acc;
	}

}
