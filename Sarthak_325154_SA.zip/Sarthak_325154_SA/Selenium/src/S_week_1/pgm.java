package S_week_1;

public class pgm {
	 public int num;
	 public String fname;
     public String lname;
	 public String email;

	 public String pass;
	 public String c_pass;
	 public String exp;

}
