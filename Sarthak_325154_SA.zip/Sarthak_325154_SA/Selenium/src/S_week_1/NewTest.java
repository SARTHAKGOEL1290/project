package S_week_1;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest {
	
	
	regis rg;
	pgm pg,ld;
	@BeforeClass
	public void isutil()
	{
		pg=new pgm();
		rg= new regis();
		ld=new pgm();
	}
  @Test(dataProvider="security")
  public void test(String gen,String name,String last,String emaill,String passs,String cnf_pss) {
	  pg.num=Integer.parseInt(gen);
	  pg.fname=name;
	  pg.lname=last;
	  pg.email=emaill;
	  pg.pass=passs;
	  pg.c_pass=cnf_pss;
	
	 ld=rg.register(pg);
	  String s="Your registration completed";
	  
	  SoftAssert sa= new SoftAssert();
	    sa.assertEquals(s,ld.exp);
		sa.assertAll();
	  
  }
  @DataProvider(name="security")
  public String [][]getdata()
  {
	  String [][]data = {{"0","sarthak","goel","goelsa1234659190@gmail.com","asdfghjkl","asdfghjkl"},
	                      {"1","sarthak1","goel1","ss6789919@gmail.com","zxcvbnm","zxcvbnm"}};
	return data;
	  
  }
  
  
}
