package S_week_1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class regis extends pgm {
	
	public pgm register(pgm testdata)
	{
		  System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		     /* launching the browser*/	       WebDriver dr= new ChromeDriver();
		     /* launching the website*/        dr.get("http://demowebshop.tricentis.com/");
				 
		                                       String s="aba"+ "aaaaabcdwxyzzz1290@gmail.com";
				
		     /* launching the register button*/	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
				
		     /* launching the radio button*/    List lb=dr.findElements(By.name("Gender"));
				                                ((WebElement)lb.get(testdata.num)).click();
			//((WebElement)lb.get(1)).click();
				 /* entering the first name*/	dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys(testdata.fname);
				 /* entering the last name*/    dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys(testdata.lname);
				 /* entering the email*/        dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(testdata.email);
				 /* entering the pass*/         dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(testdata.pass);
				
				 /* entering the confirm pass*/ dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys(testdata.c_pass);
				 /* click register button*/     dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
				 
				                           
				                               
				 /* finding the relevant text*/ String st= dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]")).getText();
				                                testdata.exp=st;
				                              
				                              
				       /*validity of valid use */String st1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
				                                
				                                  
				                                System.out.println("expected email id is---->"+ testdata.email);
				                                System.out.println("Acctual email id is ---->"+ st1);
				                                
				 /* log out */	              
				                                //WebDriverWait wt= new  WebDriverWait(dr,10);
				                              //  wt.until(ExpectedConditions.urlContains(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")))
				                                dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
				 /* close the browser*/         dr.close();
				                                System.out.println("logged out");
				                                
				                                return testdata;
				                             
	}

}
