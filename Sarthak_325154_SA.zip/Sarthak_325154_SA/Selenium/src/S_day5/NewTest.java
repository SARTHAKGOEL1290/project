package S_day5;

import org.testng.annotations.Test;

public class NewTest {
	@Test
	  public void t1() {
		  System.out.println("inside f1");
	  }
	  @Test
	  public void t2() {
		  System.out.println("inside f2");
	  }
	  @Test
	  public void t3() {
		  System.out.println("inside f3");
	  }
}
