package S_day5;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest3 {
	@BeforeClass
	public void t4()
	{
		System.out.println("I came to stadium");
	}
	@AfterClass
	public void t5()
	{
		System.out.println("I came back to home");
	}
	
	@BeforeMethod
	public void BM()
	{ 
		
		System.out.println("Hello");
		
	}
	@AfterMethod
	public void AM()
	{
		System.out.println("Bye");
	}
  @Test
  public void t1() {
	  System.out.println("I met mr.dhoni");
		
  }
  @Test
  public void t2() {
	  System.out.println("I had my lunch with kohli");
		
  }
  @Test
  public void t3() {
	  System.out.println("I too a pic with rohit");
		
  }
}
