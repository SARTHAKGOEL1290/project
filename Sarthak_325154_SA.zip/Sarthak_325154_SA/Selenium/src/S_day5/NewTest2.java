package S_day5;

import org.testng.annotations.Test;

import S_day4.check_login;
import S_day4.data_class;

public class NewTest2 {
	data_class tdd,tdd1;
	check_login cll;
  @Test
  public void t1() {
	/*  tdd= new data_class();
	  tdd1=new data_class();
	  cll=new check_login();
	  
	  tdd.email="sarthakgoel1290@gmail.com";
	  tdd.pwd="kuchnahi";
	  tdd.exp_res="Sucess";
	 
	  tdd1=cll.login(tdd);
	  System.out.println("acctual result is"+ tdd1.acc_res);
  */
	  tdd= new data_class();
	  tdd1=new data_class();
	  cll=new check_login();
	  
	  for(int i=1;i<=2;i++)
		{
			//if(i==1) {
	    data_class tdd =new data_class();
	    data_class tdd1=new data_class();
		tdd=cll.readexcel(i);
		tdd1=cll.login(tdd);
		cll.writeexcell(tdd1,i);
	    }
  }
}
