package S_day5;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest1 {
  
  @AfterMethod
  public void AM()
  {
	  System.out.println("after");
  }
  @BeforeMethod
  public void BM()
  {
	  System.out.println("before");
  }
  @Test
  public void t1() {
	  System.out.println("inside f1");
  }
  
  @Test
  public void t3() {
	  System.out.println("inside f3");
  }
  @Test
  public void t2() {
	  System.out.println("inside f2");
  }
}
