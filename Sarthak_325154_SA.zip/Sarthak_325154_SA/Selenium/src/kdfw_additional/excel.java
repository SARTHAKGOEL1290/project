package kdfw_additional;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import S_weekand2.test_case_sel;

public class excel {

String data;


     public static String filename="D://TESTDATA11.xlsx";
     public static String keyword_sh="Sheet2";
     public static String test_sel_sh="Sheet3";
     public static XSSFSheet tc_sh,kw_sh;
     
     
     public static XSSFSheet read_sheet(String sheetname)
     {
    	 XSSFSheet sh=null;
    	 try {
    			File f =new File(filename);
    			FileInputStream fis =new FileInputStream(f);
    			XSSFWorkbook wb= new XSSFWorkbook(fis);
    			 sh= wb.getSheet("Sheet2");
    		 
    	 }
    	 catch(Exception e)
    	 {
    		 e.printStackTrace();
    	 }
    	 return sh;
     }
	
	public String read(int n,int c) 
	{
		try {
		kw_sh=read_sheet(keyword_sh);
		
		XSSFRow r= kw_sh.getRow(n);
		
		XSSFCell c1=r.getCell(c);
		data=c1.getStringCellValue();
		//System.out.println(data);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return data;
	}
	public static test_case_sel readsel(int i)
	{
		test_case_sel tc=new test_case_sel();
		try {
			tc_sh=read_sheet(test_sel_sh);
			
				XSSFRow r=tc_sh.getRow(i);
				
				tc.tc_id=r.getCell(0).getStringCellValue();
				tc.flag =r.getCell(1).getStringCellValue();
				tc.no_steps=(int) r.getCell(2).getNumericCellValue();
				//tc.sheet_name=r.getCell(3).getStringCellValue();
		
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return tc;
	}
	public int write(int n)
	{
		try
		{
		File f=new File("D://TESTDATA11.xlsx");
		FileInputStream fis =new FileInputStream(f);
		XSSFWorkbook wb= new XSSFWorkbook(fis);
		XSSFSheet sh= wb.getSheet("Sheet2");
		
		XSSFRow r= sh.getRow(n);
		
		XSSFCell c=r.createCell(6);
		c.setCellValue("valid user");
		
		FileOutputStream fos= new FileOutputStream(f);
		wb.write(fos);
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}

}
