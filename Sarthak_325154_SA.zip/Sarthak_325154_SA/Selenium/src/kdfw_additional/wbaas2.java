package kdfw_additional;

import org.openqa.selenium.WebDriver;

import S_day6.excel;
import S_day6.wbaas;

public class wbaas2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String kw,loc,td;
		WebDriver dr=null;
		wbaas we= new wbaas(dr);
        excel ex= new excel();
     //   String sp=
        
        for(int i=1;i<=16;i++)
        {
        	kw=ex.read(i,3);
        	loc=ex.read(i,4);
        	td=ex.read(i,5);
        	
        	switch(kw)
        	{
        	case "launchchrome" :
        		we.launch(td);
        		break;
        		
        	case "enter_txt" :
        		we.enter(loc,td);
        		break;
        		
        	case "click_btn" :
        		we.click(loc);
        		break;
        		
        	case "verify" :
        		we.verify(loc,i,td);
        		break;
        		
        	case "sel_gen" :
        		we.gender(td);
        		break;
        	}
        }
		

	}
}
