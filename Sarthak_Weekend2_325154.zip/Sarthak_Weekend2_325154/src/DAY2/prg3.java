package DAY2;

public class prg3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		for(int i=10;i<=50;i++)
		{
			if(i%5==0) {
				if(i==50)
					System.out.print(i);
				else { 
				System.out.print(  i + "+");
			
				}
				sum=sum+i;
			
			}
		}
		
		System.out.println("="+ sum);
		
	}

}
