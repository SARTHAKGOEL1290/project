package DAY2;

import java.util.Scanner;

public class pgm7 {
 
	// program to find sum of digits greater than five
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		int sk;
		System.out.println("enter a number");
		Scanner s=new Scanner(System.in);
		
				int a=s.nextInt();
		while(a!=0)
		{
			sk=a%10;
			a=a/10;
			
			if(sk>5)
			{
				sum=sum+sk;
			}
		}
		System.out.println(sum);

	}

}
