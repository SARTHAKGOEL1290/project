package DAY4;

public class Student1 {
	int roll_no;
	String name;
	int marks;
	
	 public Student1(int roll_no,String name,int marks)
	{
		this.roll_no=roll_no;
		this.name=name;
		this.marks=marks;
	}

	 public void display()
	 { 
		 
		 System.out.print(roll_no  + " ");
		 System.out.print(name + " ");
		 System.out.print( marks + " ");
		 System.out.println();
	 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student1  s1 = new Student1(10,"rakesh",85);
		Student1  s2 = new Student1(15,"ramesh",90);
		Student1  s3 = new Student1(20,"suresh",95);
		
		s1.display();
		
		s2.display();
		s3.display();
		
	}

}
