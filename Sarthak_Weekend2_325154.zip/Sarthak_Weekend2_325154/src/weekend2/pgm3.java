package weekend2;

import java.util.ArrayList;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {23,44,84,37,91,18};
		int sum=0;
		ArrayList<Integer> arr1 = new ArrayList<Integer>();
		for(int i=0;i<arr.length;i++)
		{
			if(i%2==0 && arr[i]%2!=0)
			{
				arr1.add(arr[i]);
				sum=sum+arr[i];
			}
		}
		System.out.println("elements are--->"+ arr1 +" "+ " sum is -->"+ sum);

	}

}
