package weekend2;

public class marks_info {
	
	int rollno;
	String name;
	int java;
	int sel;
	int avg;
	public marks_info(int rollno, String name, int java, int sel) {
		this.rollno = rollno;
		this.name = name;
		this.java = java;
		this.sel = sel;
		
	}
	public void average()
	{
		this.avg= (this.java+this.sel)/2;
		
		if(avg>=65)
		{
			System.out.println("rollno is-->"+ this.rollno + "   "
				             	+ " name is--> "+ this.name + "   "
				             	+ "java marks is->>"+ this.java+ "   "
				             	+ " sel marks is--> "+ this.sel+ "   "
				             	+ "average is -->" + this.avg);
		}
		
	}
	public static void main(String args[])
	{
		marks_info m1= new marks_info(101,"aditya",90,80);
		marks_info m2= new marks_info(102,"anmol",80,10);
		marks_info m3= new marks_info(103,"shivam",70,90);
		
		m1.average();
		m2.average();
		m3.average();
	}
	
	

}
