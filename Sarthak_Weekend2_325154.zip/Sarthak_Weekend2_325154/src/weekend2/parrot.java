package weekend2;

public class parrot extends birds{
	
	public String types_of_fruit;
	public String types_of_seed;
	public String habitat;
	
	
	public void is_found()
	{
		System.out.println(" they are found in region of America");
	}
	
	public void imitate()
	{
		System.out.println(" parrots understand human speech");
	}
	
	

}
