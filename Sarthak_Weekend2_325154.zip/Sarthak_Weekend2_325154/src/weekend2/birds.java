package weekend2;

public class birds {
	public String color;
	public int weight;
	public int height;
	public String eat;
	public int  span;
	
	public void fly()
	{
		System.out.println(" they are fly atmost height"+ this.height);
	}
	
	public void life()
	{
		System.out.println(" they are life span of" + this.span);
	}

}
