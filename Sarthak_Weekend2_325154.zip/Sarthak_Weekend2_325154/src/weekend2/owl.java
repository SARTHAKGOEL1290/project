package weekend2;

public class owl extends birds {

	public String type;
	public String habitat;
	
	
	public void found()
	{
		System.out.println("owl are found in all regions");
	}
	public void eyesight()
	{
		System.out.println(" owl has very intense prey capture power");
	}
}
