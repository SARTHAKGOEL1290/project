package weekend2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class pgm2 {
	
   public ArrayList<product_info> read_excel()
   {
	ArrayList<product_info>ar_pl =new ArrayList<product_info>();
	try
	{
		File f= new File("D:\\product_info.xlsx");
		FileInputStream fis =new FileInputStream(f);
		XSSFWorkbook wb= new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet("Sheet1");
		
		int fist=sh.getFirstRowNum();
		int last=sh.getLastRowNum();
		
		int nor=last-fist+1;
		for(int i=fist+1;i<=last;i++)
		{
			product_info pg= new product_info();
			
			XSSFRow r= sh.getRow(i);
			
			XSSFCell c= r.getCell(0);
			pg.pid= (int)c.getNumericCellValue();
			
			XSSFCell c1= r.getCell(1);
			pg.pname = c1.getStringCellValue();
			
			XSSFCell c2= r.getCell(2);
			pg.pup = (int)c2.getNumericCellValue();
			
			XSSFCell c3= r.getCell(3);
			pg.nop = (int)c3.getNumericCellValue();
			
			
			pg.calc_price();
			System.out.println(pg.price);
			pg.calc_grade();
			System.out.println(pg.grade);
			ar_pl.add(pg);
			
		}
	}
	catch (FileNotFoundException e) {
		  e.printStackTrace();	
		}
		catch( IOException e)
		{
			e.printStackTrace();
		}
		return ar_pl;
	  
  }
   public void write_excel(ArrayList<product_info>arr)
   {
	   int row=1;
	   try
	   {
		   File f= new File("D://product_info.xlsx");
		   FileInputStream fis =new FileInputStream(f);
		   XSSFWorkbook wb =new XSSFWorkbook(fis);
		   XSSFSheet sh = wb.getSheet("Sheet1");
		   for(product_info pf : arr)
		   {
			   XSSFRow r= sh.getRow(row);
			   XSSFCell c= r.createCell(4);
			   c.setCellValue(pf.price);
			   
			  // XSSFRow r= sh.getRow(row);
			   XSSFCell c1= r.createCell(5);
			   c1.setCellValue(pf.grade);
			   row++;
		   }
		  
		   FileOutputStream fos =new FileOutputStream(f);
			wb.write(fos);
			
		}
			catch (FileNotFoundException e) {
				  e.printStackTrace();	
				}
				catch( IOException e)
				{
					e.printStackTrace();
				}           
	   
   }
}
