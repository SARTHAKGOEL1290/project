package weekend2;

//// prog to store the numbers in arr_list.
import java.util.ArrayList;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> arr= new ArrayList<Integer>();
		
			for(int i=10;i<=30;i++)
			{
				if(i%2==0)
					arr.add(i);
			}
			for(int i=0;i<arr.size();i++)
				System.out.print(arr.get(i)+ " ");
		

	}

}
