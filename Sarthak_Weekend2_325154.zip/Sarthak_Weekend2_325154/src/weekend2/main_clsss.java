package weekend2;

import java.util.ArrayList;

public class main_clsss {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		pgm2 pp1= new pgm2();
		ArrayList<product_info> arr_pll =new ArrayList<product_info>();
		arr_pll=pp1.read_excel();
		pp1.write_excel(arr_pll);

	}

}
