package weekend2;

/// program to print first five armstrong numbers;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int cnt=1;
		int i=1,a;
		while(cnt!=6 && i<500)
		{
			int num=i,sum=0;
		   while(num!=0)
			{
				a=num%10;
				sum=sum+ (a*a*a);
				num=num/10;
				
			}
		   if(sum==i)
			{
				System.out.println(i + " ");
				cnt++;
			}
			i++;
		}

	}

}
