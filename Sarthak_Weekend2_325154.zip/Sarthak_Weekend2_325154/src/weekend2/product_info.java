package weekend2;

public class product_info {

	int pid;
	String pname;
	int pup;
	int nop;
	int price;
	String grade;
	
	public void calc_price()
	{
		this.price=this.pup* this.nop;
	}
	public void calc_grade()
	{
		if(price<25000)
			this.grade= "A";
		if(price>=25000)
			this.grade=" B";
	}
}
