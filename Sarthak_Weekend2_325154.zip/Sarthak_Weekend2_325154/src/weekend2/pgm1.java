package weekend2;

import java.util.ArrayList;

public class pgm1 {
	
	public int is_cnt(String ch)
	{
		int count =0;
		for(int i=0;i<ch.length();i++)
		{
			char c= ch.charAt(i);
			if((c=='a')|| (c=='e') || (c=='i') || (c=='o') || (c=='u'))
    		{
    			count++;
    		}
			
		}
		return count;
		
	}
	
	public ArrayList<String>  get_each_word(String str)
	{
	  ArrayList<String> arr_st = new ArrayList<String>();
	  int lt=0,p1=0,L1=0;
	  String st;
	  while(lt!=str.length())
	  {
		  L1=str.indexOf(" ",L1);
		  st= str.substring(p1,L1);
		  
		 // if(is_cnt(st)>=3)
		  arr_st.add(st);
		 
		  p1=L1+1;
		  L1=L1+1;
		  lt=L1;
		 
		 // arr_st.add(" ");
	  }
	  
	 return arr_st;
	  
		
	}
	public ArrayList<String> count_vowels(ArrayList<String> s)
	{
	
		
	//	ArrayList<String> arr_st = new ArrayList<String>();
		ArrayList<String> st = new ArrayList<String>();
		
	    for(int i=0;i<s.size();i++)
	    {
	    	//System.out.println(s.get(i));
	    	if(is_cnt(s.get(i))>=3)
	    	st.add(s.get(i));
	    }
	    return st;
	    	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String stri="i am working in globallogic noida ";
		pgm1 pg= new pgm1();
		ArrayList<String> arr;
		ArrayList<String> arr1;
		arr=pg.get_each_word(stri);
		 arr1=pg.count_vowels(arr);
		//for(int i=0;i<=arr1.size();i++)
		//{
			System.out.println("required string is ---->" +arr1);
		//}

	}

}
