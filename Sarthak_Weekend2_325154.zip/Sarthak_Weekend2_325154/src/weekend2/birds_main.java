package weekend2;

public class birds_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		parrot p1= new parrot();
		parrot p2= new parrot();
		parrot p3= new parrot();
		
		
		owl o1=new owl();
        owl o2=new owl();
  
        
        p1.color="green";
        p1.weight=2;
        p1.eat="herbi";
        
        p1.height=20;
        p1.span=2;
        p1.types_of_fruit="orange";
        p1.types_of_seed="mirchi ";
        p1.habitat="tree";
        
        System.out.println("parrot description--->"+ p1.color+ "  " +
                           "weight is-->"+ p1.weight +"   " +
                            " they eat--->"+ p1.eat+ "   "+
                            " their life span is of"+ p1.span);
        p1.is_found();
        p1.imitate();
        
        

        System.out.println();
        System.out.println();
        System.out.println();
        
        
        p2.color=" light green";
        p2.weight=1;
        p2.eat="herbi";
        
        p2.height=25;
        p2.span=3;
        p2.types_of_fruit="banana";
        p2.types_of_seed="mirchi ";
        p2.habitat="tree";
        
        System.out.println("parrot2 description--->"+ p2.color+ "  " +
                           "weight is-->"+ p2.weight +"   " +
                            " they eat--->"+ p2.eat+ "   "+
                            " their life span is of"+ p2.span);
        p2.is_found();
        p2.imitate();
		
        System.out.println();
        System.out.println();
        
        o1.color="brown";
        o1.weight=3;
        o1.eat="carni";
        
        o1.height=15;
        o1.span=2;
        
        o1.type="insects";
        o1.habitat="all region";
        
        System.out.println("parrot description--->"+ o1.color+ "  " +
                "weight is-->"+ o1.weight +"   " +
                 " they eat--->"+ o1.eat+ "   "+
                 " their life span is of"+ o1.span+
                 " they eat --->>"+ o1.type);
        
        o1.found();
        System.out.println();
        o1.eyesight();

	}

}
