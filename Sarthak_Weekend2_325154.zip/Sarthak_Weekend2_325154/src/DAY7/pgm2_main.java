package DAY7;

import java.util.ArrayList;

import DAY3.student;

public class pgm2_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PGM1 ex= new PGM1();
		ArrayList<student> arr_li =new ArrayList<student>();
		arr_li=ex.read_excel();
		ex.write_excel(arr_li);
		  
	}

}
