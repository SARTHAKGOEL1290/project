package DAY3;

public class pgm3 {
	 
	/*public static void findpair(int arr[],int num)
	{
		
	}*/
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr1[]= {21,34,91,59,16,44,29,36,49,31};
		int num1=65;
		
		for(int i=0;i<arr1.length;i++)
		{
			for(int j=0;j<arr1.length;j++)
			{
				if(arr1[i]+arr1[j]==num1)
					System.out.println(arr1[i]+ " " +arr1[j]+ "=" +num1);
			}
		}
	}

}
