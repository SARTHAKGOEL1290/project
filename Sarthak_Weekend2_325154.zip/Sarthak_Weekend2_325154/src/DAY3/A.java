package DAY3;

public class A {
	int abc;
	
	public void show1()
	{
		System.out.print("this is variable of class A" + " ");
		System.out.println(this.abc);
	}

}
