package DAY3;

public class prg1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int arr[]= {80,80,60,50,40,30};
       int avg,sum=0;
       for(int i=0;i<6;i++)
       {
    	   sum=sum+arr[i];
       }
       avg=sum/6;
       System.out.println(avg);
	}

}
