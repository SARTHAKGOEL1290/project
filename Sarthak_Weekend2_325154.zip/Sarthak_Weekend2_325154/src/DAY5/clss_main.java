package DAY5;

import DAY3.student;

public class clss_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		cls excell = new cls();
		
		for(int i=1;i<=2;i++) {
		student s1= excell.read_excel(i);
		s1.average();
		
		excell.write_excel(s1,i);
		}
	}

}
