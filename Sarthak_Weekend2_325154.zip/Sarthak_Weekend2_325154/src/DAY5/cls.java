package DAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import DAY3.student;

public class cls {
	
	
	public student read_excel(int n)
	{
		// TODO Auto-generated method stub
		
		student std= new student();
					try {
						File f =new File("D:\\student_info.xlsx");
						FileInputStream fis = new FileInputStream(f);
						XSSFWorkbook wb = new XSSFWorkbook(fis);
						XSSFSheet sh = wb.getSheet("Sheet1");

						XSSFRow r=sh.getRow(n);
						
						XSSFCell c= r.getCell(0);
						std.roll_no= (int) c.getNumericCellValue();
						
						XSSFCell c1 =r.getCell(1);
						std.name = c1.getStringCellValue();
						
						
						XSSFCell c2 =r.getCell(2);
				        std.m1 = (int) c2.getNumericCellValue();
				        
				        XSSFCell c3 =r.getCell(3);
				        std.m2 = (int) c3.getNumericCellValue();
						
						
					//	String s= c.getStringCellValue();
						//System.out.println(s);
					}
					catch (FileNotFoundException e) {
					  e.printStackTrace();	
					}
					catch( IOException e)
					{
						e.printStackTrace();
					}
 
					return std;
	}
	public void write_excel(student std,int n)
	{
		
	try {
		File f =new File("D:\\student_info.xlsx");
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet("Sheet1");
		XSSFRow r=sh.getRow(n);
		XSSFCell c= r.createCell(4);
		
		
		// for writing into excell file
        
		c.setCellValue((double) std.avg);
	   FileOutputStream fos = new FileOutputStream(f);
	   wb.write(fos);
	}
	catch (FileNotFoundException e) {
	  e.printStackTrace();	
	}
	catch( IOException e)
	{
		e.printStackTrace();
	}

}

}
