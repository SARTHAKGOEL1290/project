package DAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

//import java.io.File;
//import java.io.FileInputStream;

//import org.apache.poi.xssf.usermodel.XSSFCell;


public class pgm3 {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		try {
			File f =new File("D:\\Book1.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(0);
			XSSFCell c= r.getCell(0);
			
			String s= c.getStringCellValue();
			System.out.println(s);
			
			
			// for writing into excell file
            
			c.setCellValue("sart");
		   FileOutputStream fos = new FileOutputStream(f);
		   wb.write(fos);
		}
		catch (FileNotFoundException e) {
		  e.printStackTrace();	
		}
		catch( IOException e)
		{
			e.printStackTrace();
		}

	}

}
