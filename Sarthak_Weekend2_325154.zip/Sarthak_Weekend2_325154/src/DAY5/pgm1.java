package DAY5;

public class pgm1 {

	// prog for exception handling
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       try {
		int arr[]= {1,2,3};
		System.out.println(arr[3]);
		 
		//try {
		
		int n=100,m=0,p;
      p=n/m;
      System.out.println(p);
		}
		
      // }
       catch(ArithmeticException e)
       {
    	  System.out.println("in catch");
    	   
       }
      catch(ArrayIndexOutOfBoundsException e)
      {
    	  System.out.println("catching array exep");
      }
       System.out.println("outside catch block");
		
		
		
	}

}
