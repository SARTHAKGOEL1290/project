package DAY10;

public class table4 {

	public int custt_id;
	public String c_name;
	public String from;
	public String to;
	public  int unit_price;
	public int not;
	public int total;
}
