package DAY10;

//public class table1 {

public class table1 {
	
	public int rid;
	public String from;
	public String to;
	public int unit_price;
	public void display() {
		// TODO Auto-generated method stub
		
	}

}



