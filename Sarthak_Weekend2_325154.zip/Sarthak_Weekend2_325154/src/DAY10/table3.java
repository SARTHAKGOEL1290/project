package DAY10;

public class table3 {
	
	public int cid;
	public int rid;
	public int no_of_tick;
	public void display() {
		// TODO Auto-generated method stub
		
		System.out.println(this.cid+ "  " + this.rid + "  " + this.no_of_tick);
		
	}

}
