package DAY8;

public class passanger {

	public int sr_no;
	public String name;
	public String from;
	public String to;
	public int rate;
	public int no_of_seats;
	 
	public int total;
	
	public void calc_ttl()
	{
	    this.  total=this.rate* this.no_of_seats;                           
		
	}
}

