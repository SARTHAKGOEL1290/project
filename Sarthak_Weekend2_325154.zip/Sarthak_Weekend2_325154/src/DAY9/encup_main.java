package DAY9;

public class encup_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		encup e1= new encup();
		e1.setAcc_no(10001);
		e1.setAcc_bal(25000);
		
		System.out.println("Account no "+ e1.getAcc_no()+"\n"
		                    + "account bal"+ e1.getAcc_bal());
	}

}
