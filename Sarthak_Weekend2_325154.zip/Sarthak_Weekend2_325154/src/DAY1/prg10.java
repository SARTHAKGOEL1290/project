package DAY1;

public class prg10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A=10,B=5,C=8;
		if(A>B && A>C)
			System.out.println("A is largets");
		else if(B>A && B>C)
			System.out.println("B is largest");
		else
			System.out.println("C is largest");
		

	}

}
