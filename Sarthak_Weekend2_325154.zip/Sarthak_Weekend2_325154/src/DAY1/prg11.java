package DAY1;

import java.util.Scanner;


public class prg11 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter a number");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		System.out.println("enter second number");
		int b=sc.nextInt();
		System.out.println("enter third number");
		int c=sc.nextInt();
		
		float marks=(a+b+c)/3;
		
		if(marks>=60)
			System.out.println("first class");
		else if(marks>=50 && marks<60)
			System.out.println("second class");
		else
			System.out.println("third class");
		
	}

}
