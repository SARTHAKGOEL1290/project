package weekend1;

import java.util.ArrayList;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 ArrayList<Integer> arr1 = new ArrayList<Integer>();
		 ArrayList<Integer> arr2 = new ArrayList<Integer>(); 
		//int arr1[]=new int[7];
		//int arr2[]=new int[7];
		
		int c=0,d=0;
	for(int i=10;i<=30;i++)
		{
			if(i%3==0) {
				arr1.add(i);
			}
		}
	for(int i=10;i<=30;i++)
		{
			if(i%5==0) {
				arr2.add(i);
			}
		}
		for(int i=0;i<arr1.size();i++ )
		System.out.print(arr1.get(i) + " ");
		
		
		System.out.println();
		
		for(int i=0;i<arr2.size();i++ )
			System.out.print(arr2.get(i) + " ");
		
		
		System.out.println();
			
		System.out.println("first aar" + "  " +"second arr" +  " " + "output arr");
		
		for(int i=0;i<arr1.size();i++ )
		{
			for(int j=0;j<arr2.size();j++ )
			{
				if(arr1.get(i)+arr2.get(j)>30 && arr1.get(i)+arr2.get(j)<=40)
				{ 
					int m=arr1.get(i)+arr2.get(j);
					System.out.println(arr1.get(i)+ "         "+ arr2.get(j) +"         "+ m);
				}
			}
		}

	}

}
