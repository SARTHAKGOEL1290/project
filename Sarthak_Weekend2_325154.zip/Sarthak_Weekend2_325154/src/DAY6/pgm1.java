package DAY6;

import java.util.ArrayList;

public class pgm1 {
	
	public static void main(String args[])
	{
		String str[]= {"hi","all","nndck"};
		
		for(String s: str)
			System.out.println(s);
		ArrayList<String> st= new ArrayList<String>();
		
		st.add("asf");
		st.add("rakesh" );
		st.add("kesh" );
		st.add("mesh" );
		
		System.out.println("before insertion" + st);
		
		st.add("priya");
		System.out.println("after inserion"  + st);
		
		st.remove("asf");
		
		
		
	}

}
