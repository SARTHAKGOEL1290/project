package DAY6;

public class std {
	
	public String name;
	public int roll_no;
	public int sel;
	public int java;
	public int avg;
	
	public void calc_avg()
	{
		this.avg= (this.sel +this.java)/2;
	}

	public std(String name,  int roll_no,int sel, int java) {

		this.name = name;
		this.roll_no=roll_no;
		this.sel = sel;
		this.java = java;

	}
	
	

}
