package DAY6;

import java.util.ArrayList;

import DAY4.Student1;

public class pgm2 {

	ArrayList<std> arr_st=new ArrayList<std>();
	
	public void create_al()
	{
		std s1= new std("ramesh",101,80,70) ;
		std s2=new std ("shaym",102,90,80);
		
		arr_st.add(s1);
		arr_st.add(s2);
		
	}
	public void display()
	{
		for(std st : arr_st)
		{
			st.calc_avg();
			System.out.println("name is --" + st.name + " /n"
					            + " roll no is ---"+ st.roll_no + " /n"
					            + "sel marks is ---"+ st.sel + "/n"
					            + " java marks is ---" + st.java +" /n"
					            + "avg is --------"+ st.avg);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		pgm2 arr2= new pgm2();
		arr2.create_al();
		arr2.display();
		

	}

}
