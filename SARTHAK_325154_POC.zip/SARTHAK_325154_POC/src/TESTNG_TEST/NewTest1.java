package TESTNG_TEST;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BASE_CLASSES.cart;
import BASE_CLASSES.checkout;
import BASE_CLASSES.complete;
import BASE_CLASSES.data;
import BASE_CLASSES.home;
import BASE_CLASSES.logn;
import BASE_CLASSES.overview;
import BASE_CLASSES.readex;


public class NewTest1 extends readex {
	logn lp;
	home hp;
	cart cp;
	checkout ckp;
	overview cko;
	complete cpp;
	WebDriver dr;
	data dd;
	static int ptr=1;
	public static ArrayList<data> ar=new ArrayList<data>();
	@BeforeClass
	public void con()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		dr=new ChromeDriver();
		 dr.get("http://www.saucedemo.com/");
	    
		 lp=new logn(dr);
		 hp=new home(dr);
		 cp=new cart(dr);
		 ckp=new checkout(dr);
		 cko=new overview(dr);
		 dd=new data("as","is",1);
		 cpp=new complete(dr);
		 
	
		 data11=new String[2][2];
		  for(int row=1;row<=2;row++)
		  {
			 get_text(row);
			
		  }
		  
		  logn.login("standard_user","secret_sauce");
		 ar= home.add_inlist();
	}
	@Test
	public void for_login_verify()
	{
String exp="Products";
		
		String acc_txt= home.is_check();
		
		SoftAssert sa =new SoftAssert();
	     sa.assertEquals(exp, acc_txt);
	     
	     sa.assertAll();
	     System.out.println("compare methaod is-->>pass");
	}
	@Test(dataProvider="secure")
	public void for_product_verify(String s,String u)
	{
		// int i =Integer.parseInt(a);
		int i= home.search_prod(s,ar);
		System.out.println(i);
			String exp=   home.get_prod_name(i);
			    home.get_prod_price(i);
				 home.add_cart(i);
				
				 home.click_btn();
				  
				String acc = cart.verify_name(ptr++);
				
				//Logger log =Logger.getLogger("global");
			//	    log.info("Test_case id  --->>> "+ptr+"   " + "expected name is-->>>" + a+"   "  +"acctual name is   "+acc);
				   
				     SoftAssert sa =new SoftAssert();
				     sa.assertEquals(exp, acc);
				     sa.assertAll();
	}
	@DataProvider(name="secure")
	public String[][] dp()
	{
		return data11;
	}
	
	 @Test
	 public void give_ur_info()
	 {
         checkout.proceed("sarthak12","Goel12","247001");
	     overview.total_bill();
	     overview.do_final();
	     complete.give_details();
	 }
	
}
