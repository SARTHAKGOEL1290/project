package BASE_CLASSES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class complete {
	static WebDriver dr;
	public complete(WebDriver dr)
	{
		complete.dr=dr;
		PageFactory.initElements(dr, this);
	}
	public static void give_details()
	{
		String st1=dr.findElement(By.xpath("//*[@id=\"checkout_complete_container\"]/h2")).getText();
		String st2=dr.findElement(By.xpath("//*[@id=\"checkout_complete_container\"]/div[1]\r\n")).getText();
		
		System.out.println("Your order status is---->>>"+st1);
		System.out.println("Your delivery details is--->>>"+st2);
		
	//	dr.findElement(By.xpath("//*[@id=\"menu_button_container\"]/div/div[3]/div/button")).click();
		//dr.findElement(By.xpath("//a[@id='inventory_sidebar_link']")).click();
	}


}
