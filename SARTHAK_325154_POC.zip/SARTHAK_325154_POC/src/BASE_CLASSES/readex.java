package BASE_CLASSES;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class readex {
	
	public static String [][]data11;
	public static int row,col;
	
	public static void get_text(int n)
	{
		try
		{
			
			File f= new File("D://poc_test_data.xlsx");
			FileInputStream fis= new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh= wb.getSheet("Sheet1");
			
		
			XSSFRow r= sh.getRow(n);
			
			System.out.println("is");
			
			XSSFCell c=r.getCell(0);
			System.out.println(c.getStringCellValue());
			data11[n-1][0]=c.getStringCellValue();
			System.out.println(data11[1][1]);
			
			System.out.println("hello");
			XSSFCell c1= r.getCell(1);
            data11[n-1][1]=c1.getStringCellValue();
			
			
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

}
