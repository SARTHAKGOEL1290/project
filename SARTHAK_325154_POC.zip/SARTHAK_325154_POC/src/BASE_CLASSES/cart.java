package BASE_CLASSES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class cart {
	
	static WebDriver dr;
	static String base_xp1="//div[@class='cart_item'][";
	static By xconf,pconf;
	static float total_sum=0;
	
	public cart(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	public  static String verify_name(int n)
	{
	   xconf=By.xpath(base_xp1+n+"]//div[@class='inventory_item_name']");
	   String acc=dr.findElement(xconf).getText();
	   System.out.println("acctual name is ---->>>"+acc);
	   
	   
	   pconf=By.xpath(base_xp1+n+"]//div[@class='inventory_item_price']");
	    String acc_prc=dr.findElement(pconf).getText();
	    float f=Float.parseFloat(acc_prc);  
	    
	  //  total_sum +=f;
	    System.out.println("acctual price is ---->>>"+acc_prc);
	    
	  dr.findElement(By.xpath("//a[@class='btn_secondary']")).click();
	 return acc;
	}
	/*public  void verify_price(int n)
	{
		pconf=By.xpath(base_xp1+n+"]//div[@class='inventory_item_price']");
	    String acc_prc=dr.findElement(pconf).getText();
	    System.out.println("acctual price is ---->>>"+acc_prc);
	   // return acc_prc;
	}*/
	public static void check_out()
	{
		dr.findElement(By.xpath("//a[@class='btn_action checkout_button']")).click();
	}


}
