package BASE_CLASSES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class logn {
	static WebDriver dr;
	static By xname= By.xpath("//*[@id=\"user-name\"]");
	static By xpwd= By.xpath("//*[@id=\"password\"]");
	static By xbtn= By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]");
	
	
	
	public  logn(WebDriver dr)
	{
		logn.dr=dr;
		PageFactory.initElements(dr, this);
	}
	public static void name(String uid)
	{
		dr.findElement(xname).sendKeys(uid);
	}
	public static void pass(String pwd)
	{
		dr.findElement(xpwd).sendKeys(pwd);
	}
	public static void clic()
	{
		dr.findElement(xbtn).click();
	}
	
	public  static void login(String uid,String pwd)
	{
		
		name(uid);
		pass(pwd);
		clic();
		
	}
	public String get_login_title()
	{
		return dr.getTitle();
	}
	

}
