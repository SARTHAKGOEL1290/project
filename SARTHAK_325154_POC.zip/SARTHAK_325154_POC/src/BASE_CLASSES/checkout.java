package BASE_CLASSES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class checkout {
	
	
	static WebDriver dr;
	static By xfname= By.xpath("//input[@id='first-name']");
	static By xlname= By.xpath("//input[@id='last-name']");
	static By xpcode= By.xpath("//input[@id='postal-code']");
	static By conti=  By.xpath("//input[@class='btn_primary cart_button']");
	
	
	public checkout(WebDriver dr)
	{
		checkout.dr=dr;
		PageFactory.initElements(dr, this);
	}
	public static void fist_name(String fis)
	{
		dr.findElement(xfname).sendKeys(fis);
	}
	public static void last_name(String las)
	{
		dr.findElement(xlname).sendKeys(las);
	}
	public static void postal(String pcd)
	{
		dr.findElement(xpcode).sendKeys(pcd);
	}
	public static void clic_conti()
	{
		dr.findElement(conti).click();
	}
	public static void proceed(String fnme,String lnme,String pos)
	{
		dr.get("https://www.saucedemo.com/checkout-step-one.html");
		fist_name(fnme);
		last_name(lnme);
		postal(pos);
		clic_conti();
		
	}


}
