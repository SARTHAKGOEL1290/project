package BASE_CLASSES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class overview {
	
	static WebDriver dr;
	//div[@class='summary_subtotal_label']
	//div[@class='summary_tax_label']
	//div[@class='summary_total_label']
	//a[@class='btn_action cart_button']
	
	public overview(WebDriver dr)
	{
		overview.dr=dr;
		PageFactory.initElements(dr, this);
	}
	public static void total_bill()
	{
		
		String ssl=dr.findElement(By.xpath("//div[@class='summary_subtotal_label']")).getText();
		String stl=dr.findElement(By.xpath("//div[@class='summary_tax_label']")).getText();
		String  stotal=dr.findElement(By.xpath("//div[@class='summary_total_label']")).getText();
		
		System.out.println("Your total bill is --->"+ stotal);
	}
	public static void do_final()
	{
		dr.findElement(By.xpath("//a[@class='btn_action cart_button']")).click();
	}


}
