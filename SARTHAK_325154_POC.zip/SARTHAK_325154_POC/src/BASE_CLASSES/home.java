package BASE_CLASSES;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;


public class home
{

	static WebDriver dr;
	static String base_xp=" //div[@class='inventory_item'][";
	
	static By xname;
	static By xprice;
	static By xbtn;
	
//	public static ;
	static data tdd;

	
	public home(WebDriver dr) {
		home.dr=dr;
		PageFactory.initElements(dr, this);
	}
	public static String is_check()
	{
	
		String acc= dr.findElement(By.xpath("//div[@class='product_label']")).getText();
		
		return acc;
	}
	public static ArrayList<data> add_inlist()
	{
		ArrayList<data>  arr= new ArrayList<data>();
		data dp1=new data("Sauce Labs Backpack","29.9",1);
	    data dp2=new data("Sauce Labs Bike Light","9.99",2);
		data dp3=new data("Sauce Labs Bolt T-Shirt ","15.99",3);
		data dp4=new data("Sauce Labs Fleece Jacket","49.99",4);
		data dp5=new data("Sauce Labs Onesie","7.99",5);
		data dp6=new data("Sauce Labs Test.allTheThings","15.99",6);
		
		arr.add(dp1);
		arr.add(dp2);
		arr.add(dp3);
		arr.add(dp4);
		arr.add(dp5);
		arr.add(dp6);
		System.out.println(arr.get(0));
		System.out.println(arr.get(1));
		System.out.println(arr.get(2));
		System.out.println(arr.get(3));
		System.out.println(arr.get(4));
		System.out.println(arr.get(5));
		
		return arr;
		
	}
	public static int search_prod(String p_name,ArrayList<data> ar1)
	{
		int x=0;
		int fp=-1;
		System.out.println(p_name);
		for(data tdd : ar1)
		{

			System.out.println("name is--->" + tdd.pname);
			if(tdd.pname.equals(p_name)==true)
			{
				x=data.xpth;
				fp=0;
			}
		}
		if(fp==-1)
		{
			x=1;
		}
				return x;
		
	}
		
	
	public static String get_prod_name(int n)
	{
		xname=By.xpath(base_xp+n+"]//div[@class='inventory_item_name']");
		String pname=dr.findElement(xname).getText();
		System.out.println("expected name is---->>>"+pname);
	   return pname;
	}
	public static void get_prod_price(int n)
	{
		xprice=By.xpath(base_xp+n+"]//div[@class='inventory_item_price']");
		String price=dr.findElement(xprice).getText();
		System.out.println("expexted price is ---->>>"+price);
		//return price;
	}
	public static void add_cart(int n)
	{
		xbtn=By.xpath(base_xp+n+"]//button");
	     dr.findElement(xbtn).click();
	}
	public static void click_btn()
	{
		dr.findElement(By.xpath("//div[@class='shopping_cart_container']")).click();
	}
	

}
