package BASE_CLASSES;

public class data {
	

	public  static  String pname;
    public  static String price;
    public static  int xpth;
    
	public data(String pname, String price, int xpth) {

		data.pname = pname;
		data.price = price;
		data.xpth = xpth;
	}
    

}
