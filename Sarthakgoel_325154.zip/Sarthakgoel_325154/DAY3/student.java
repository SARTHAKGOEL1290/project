package DAY3;

public class student {

	int roll_no;
	String name;
	int m1;
	int m2;
	float avg;
	
	public void retavg() {
	 
		avg=(m1+m2)/2.0f;
		//return avg;
	}
	


}