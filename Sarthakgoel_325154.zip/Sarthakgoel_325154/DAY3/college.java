package DAY3;

public class college {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student rakesh= new student();
		student priya= new student();
		
		rakesh.roll_no=73;
		rakesh.name= "rakesh";
		rakesh.m1=83;
		rakesh.m2=91;
		rakesh.retavg();
		
		System.out.println(rakesh.avg);
		
		priya.roll_no=74;
		priya.name= "priya";
		priya.m1=83;
		priya.m2=99;
        
		priya.retavg();
		System.out.println(priya.avg);
	}

}
