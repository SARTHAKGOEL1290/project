package DAY3;

public class pgm5 {
	
	public static boolean iseven(int num)
	{

			if(num%2==0)
			{
				return true;
			}
		
		return false;
	}
	public static void main(String args[])
	{
		int sum=0;
		int arr1[]= {2,3,4,5,6,7,8,9};
		for(int i=0;i<arr1.length;i++) {
			if(iseven(arr1[i])==true)
				sum=sum+arr1[i];
		}
		
		System.out.println(sum);
	}

	

}
