package DAY2;

//import java.util
//import java.util.Scanner;*;

public class pgm1 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int s=3;
		 switch(s) {
		 
		 case(2):
		 System.out.println("two");
		 
		 case(5):
		 System.out.println("five");
		 
		 case(9):
		 System.out.println("nine");
		 
		 default:
		 System.out.println("derfault value");
		 }

	}

}