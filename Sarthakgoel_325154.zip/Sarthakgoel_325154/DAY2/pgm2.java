package DAY2;

//import java.util.Scanner;
import java.util.*;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter a number");
		Scanner sc= new Scanner(System.in);
		int a= sc.nextInt();
	/*	
		String str1 = Integer.toString(a);
		//System.out.println(str1);
		//String str2= str1.reverse()
		for(int i=0;i<str1.length();i++)
		{
			char s1= str1.charAt(i);
			 int num=Integer.parseInt(String.valueOf(s1));
		*/
		int num;
		while(a!=0)
		{
		num=a%10;
		a=a/10;
		
		   switch(num)
			{
			case(0):
				System.out.println("zero");
			    break;
			case(1):
				System.out.println("one");
			    break;
			case(2):
				System.out.println("two");
			    break;
			case(3):
				System.out.println("three");
			    break;
			case(4):
				System.out.println("four");
			    break;
			case(5):
				System.out.println("five");
			    break;
			case(6):
				System.out.println("six");
			    break;
			case(7):
				System.out.println("seven");
			    break;
			case(8):
				System.out.println("eignt");
			    break;
			case(9):
				System.out.println("nine");
			    break;
			}
		}
		

	}

}
