package DAY1;

public class prog1 {	
		
	    
	    public static void main (String[] args)  
	    { 
	        
	    	int num1 = 4562;
	        int mnmmm=num1;
	    	int rev = 0; 
	        while(num1 > 0) 
	        { 
	            rev = rev * 10 + num1 % 10; 
	            num1 = num1 / 10; 
	        } 
	        System.out.println(rev);
	        
	        
	        if(rev==mnmmm)
	        	System.out.println("true");
	        else
	        	System.out.println("false");
	    } 

	

}
