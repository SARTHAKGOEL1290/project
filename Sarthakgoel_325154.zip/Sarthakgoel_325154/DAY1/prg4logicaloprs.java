package DAY1;

public class prg4logicaloprs {

	public static void main(String[] args) {
		
		
		// TODO Auto-generated method stub

		int x=10;
		int b=15;
	
		//follow the sequence of variables and operators
		//if there is a variable then stop there and resume the sequence fro there only
		
		System.out.println(x++);
		System.out.println(++x);
		System.out.println(x--);
		System.out.println(++x + b-- - --b );
	}

}
