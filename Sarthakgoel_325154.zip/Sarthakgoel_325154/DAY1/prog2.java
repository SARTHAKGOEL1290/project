package DAY1;

public class prog2 {
	
	
	static boolean isprime(int num)
	{
		if(num<=1)
			return false;
		
		for(int i=2;i<num/2;i++)
		{
			if(num%i==0)
				return false;
			
		}
		return true;
		
	}

	public static void main(String[] args) {
		int counter=0;
		System.out.println("prime numbers in a range");
	  for(int i=2;i<30;i++)
	  {
		  if(isprime(i)) {
		  System.out.print(i + " ");
		  counter +=i;
		  }
	  }
  System.out.println("=" +counter);
}
	}
